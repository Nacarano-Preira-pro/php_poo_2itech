<?php

namespace M2i\Poo\Migrations;


use M2i\Framework\AbstractMigration;

class Migration202204131130 extends AbstractMigration
{
    public function up()
    {
        $this->addSql('');

        $this->execute();
    }

    public function down()
    {
        $this->addSql('');

        $this->execute();
    }
}
